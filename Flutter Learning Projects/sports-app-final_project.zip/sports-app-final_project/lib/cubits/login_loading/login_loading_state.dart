part of 'login_loading_cubit.dart';

@immutable
sealed class LoginLoadingState {}

final class LoginLoadingInitial extends LoginLoadingState {}
