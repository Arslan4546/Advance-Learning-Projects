 class ImageConstants {
 static const String splashimage = "asset/images/The Intersection Of AI And Human Creativity_ Can Machines Really Be Creative_.jpg";
 }