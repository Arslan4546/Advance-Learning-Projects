package com.example.quiz_app_aug09

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
