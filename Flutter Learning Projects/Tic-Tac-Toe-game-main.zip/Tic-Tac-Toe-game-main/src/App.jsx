
import './App.css'
import Tictactoe from "./components/tictactoe.jsx";

function App() {


  return (
    <div >
      <Tictactoe/>

    </div>
  )
}

export default App
