import 'package:flutter/material.dart';
import 'package:smart_home_animation/core/app/app.dart';

void main() {
  runApp(const SmartHomeApp());
}
