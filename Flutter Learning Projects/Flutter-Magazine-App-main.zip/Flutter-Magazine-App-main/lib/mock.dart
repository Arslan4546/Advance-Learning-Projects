const SINGLE_ARTICLE_CHUNK_1 =
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse pretium pulvinar erat non ornare. Maecenas porta turpis vitae odio porta suscipit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eget auctor dolor.";
const SINGLE_ARTICLE_CHUNK_2 =
    "Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam pulvinar, ex ut vehicula condimentum, risus tellus dignissim nulla, id dapibus lorem est nec velit. Nulla rhoncus lorem massa, id dignissim mi eleifend a.";
