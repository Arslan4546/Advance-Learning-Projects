A beautiful magazine app

Design : [dribbble](https://dribbble.com/shots/6220712-Mood-Mobile)

Features ....
1 . Parallax animation
2 . Reveal animation ( Opacity and translate y axis )
3 . Hero animation
