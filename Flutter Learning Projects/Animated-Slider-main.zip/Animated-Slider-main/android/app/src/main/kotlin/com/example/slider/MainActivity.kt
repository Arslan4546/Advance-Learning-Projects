package com.example.slider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
