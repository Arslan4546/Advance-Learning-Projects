# Custom Animated Slider

## Screenshots

<img src="https://raw.githubusercontent.com/imSanjaySoni/Animated-Slider/main/screenshots/demo.gif" alt="Demo"  width=320 />
