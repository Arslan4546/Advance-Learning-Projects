package com.example.coffee_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
