final dummyCoffeeData = [
  {
    'image': 'assets/images/coffee/coffee 1.png',
    'name': 'Macchiato',
  },
  {
    'image': 'assets/images/coffee/coffee 2.png',
    'name': 'Espresso',
  },
  {
    'image': 'assets/images/coffee/coffee 3.png',
    'name': 'Latte',
  },
  {
    'image': 'assets/images/coffee/coffee 4.png',
    'name': 'Black',
  },
];
