class RouteName {
  static const homePage = '/Home';
  static const quantityPage = '/Quantity';
  static const mixingPage = '/Mixing';
}
