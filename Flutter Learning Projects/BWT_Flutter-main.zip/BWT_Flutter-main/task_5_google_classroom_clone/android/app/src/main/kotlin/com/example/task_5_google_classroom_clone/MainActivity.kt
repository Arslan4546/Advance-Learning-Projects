package com.example.task_5_google_classroom_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
