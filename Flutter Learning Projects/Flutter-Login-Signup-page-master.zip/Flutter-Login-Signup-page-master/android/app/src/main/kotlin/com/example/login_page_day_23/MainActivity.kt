package com.example.login_page_day_23

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
